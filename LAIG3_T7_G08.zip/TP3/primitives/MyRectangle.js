/**
 * MyRectangle
 * @constructor
 * @param scene - Reference to MyScene object
 * @param x1 - x coordinate corner 1
 * @param y1 - y coordinate corner 1
 * @param x2 - x coordinate corner 2
 * @param y2 - y coordinate corner 2
 */
class MyRectangle extends CGFobject {
    constructor(scene, x1, y1, x2, y2) {
        super(scene);
        this.x1 = x1;
        this.x2 = x2;
        this.y1 = y1;
        this.y2 = y2;

        this.updatedTexCoords = false;

        this.initBuffers();
    }

    initBuffers() {
        this.vertices = [
            this.x1, this.y1, 0,	//0
            this.x2, this.y1, 0,	//1
            this.x1, this.y2, 0,	//2
            this.x2, this.y2, 0		//3
        ];

        /*  2 |--------------\ 3
              |			     \
              |			     \
            0 |--------------\ 1
        */

        //Counter-clockwise reference of vertices
        this.indices = [
            0, 1, 2,
            1, 3, 2,
        ];

        //Facing Z positive
        this.normals = [
            0, 0, 1,
            0, 0, 1,
            0, 0, 1,
            0, 0, 1
        ];

        /*
        Texture coords (s,t)
        +----------> s
        |
        |
        |
        v
        t
        */

        this.length = (this.x2 - this.x1)
        this.height = (this.y2 - this.y1)

        this.texCoords = [
            0, 1,
            1, 1,
            0, 0,
            1, 0
        ]
        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }

    /**
     * @method updateTexCoords
     * Updates the list of texture coordinates of the rectangle
     */
    updateTexCoords(coords) {
        this.texCoords = [
            0, this.height / coords.aft,
            this.length / coords.afs, this.height / coords.aft,
            0, 0,
            this.length / coords.afs, 0,
        ]
        this.updateTexCoordsGLBuffers();
        this.updatedTexCoords = true;
    }
}

